#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QKeyEvent>
#include <QTimer>
#include <QMessageBox>
#include <QCloseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    gameTimer = new QTimer(this);
    connect(gameTimer, SIGNAL(timeout()), this, SLOT(updateGame()));

    paddleWidth = 60;
    paddleHeight = 10;
    paddleSpeed = 10;

    ballSize = 10;
    ballSpeed = 3;

    playerPaddle = QRect(width() - paddleWidth, height() - paddleHeight, paddleWidth, paddleHeight);
    computerPaddle = QRect(width() - paddleWidth, 0, paddleWidth, paddleHeight);
    ball = QRect(width() / 2 - ballSize / 2, height() / 2 - ballSize / 2, ballSize, ballSize);

    ballDirection = QPoint(1, 1);

    score = 0;

    setFocus();

    gameMode = Active;
    gameTimer->start(16);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);

    painter.fillRect(playerPaddle, Qt::black);
    painter.fillRect(computerPaddle, Qt::black);
    painter.fillRect(ball, Qt::red);

    painter.drawText(10, 20, "Score: " + QString::number(score));
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Left)
        movePlayerPaddleLeft();
    else if (event->key() == Qt::Key_Right)
        movePlayerPaddleRight();
}

void MainWindow::updateGame()
{
    if (gameMode == Active) {
        moveBall();
        moveComputerPaddle();
        checkCollisions();
        update();
    } else if (gameMode == GameOver) {
        gameTimer->stop();
        showGameOverMessage();
        restartGame();
    }
}

void MainWindow::moveBall()
{
    ball.translate(ballSpeed * ballDirection.x(), ballSpeed * ballDirection.y());

    // Перевіряємо, чи м'яч вдаряється у верхню чи нижню межі екрану
    if (ball.top() <= 0 || ball.bottom() >= height()) {
        // Перевіряємо, чи м'яч відбивається від площадки гравця
        if (ball.intersects(playerPaddle)) {
            ballDirection.setY(-ballDirection.y());
            score++;  // Збільшуємо рахунок тільки при відбитті від площадки гравця
        } else {
            // Якщо м'яч не відбивається від площадки гравця - гра закінчена
            gameMode = GameOver;
            gameTimer->stop();
            showGameOverMessage();
            restartGame();
            return;
        }
    }

    // Перевіряємо, чи м'яч вдаряється у бокові межі екрану
    if (ball.left() <= 0 || ball.right() >= width()) {
        ballDirection.setX(-ballDirection.x());
    }

    // Перевіряємо, чи м'яч відбивається від площадки комп'ютера
    if (ball.intersects(computerPaddle)) {
        ballDirection.setY(-ballDirection.y());
    }
}

void MainWindow::movePlayerPaddleLeft()
{
    int newX = playerPaddle.x() - paddleSpeed;
    if (newX >= 0)
        playerPaddle.moveTo(newX, playerPaddle.y());
}

void MainWindow::movePlayerPaddleRight()
{
    int newX = playerPaddle.x() + paddleSpeed;
    if (newX <= width() - paddleWidth)
        playerPaddle.moveTo(newX, playerPaddle.y());
}

void MainWindow::moveComputerPaddle()
{
    // AI для комп'ютерної площадки
    int targetX = ball.x() - (paddleWidth / 2);
    int currentX = computerPaddle.x();

    if (targetX < currentX)
        currentX -= paddleSpeed;
    else if (targetX > currentX)
        currentX += paddleSpeed;

    // Перевіряємо, щоб площадка залишалася в межах
    if (currentX < 0)
        currentX = 0;
    else if (currentX > width() - paddleWidth)
        currentX = width() - paddleWidth;

    computerPaddle.moveTo(currentX, computerPaddle.y());
}

void MainWindow::checkCollisions()
{
    // Колізія м'яча з верхньою межею
    if (ball.top() <= 0)
        ballDirection.setY(-ballDirection.y());
}

void MainWindow::showGameOverMessage()
{
    QMessageBox gameOverMessageBox;
    gameOverMessageBox.setText("Гра закінчена. Ваш рахунок: " + QString::number(score));
    gameOverMessageBox.exec();
}

void MainWindow::startGame()
{
    gameMode = Active;
    resetGame();
    gameTimer->start(16);
}

void MainWindow::restartGame()
{
    QPushButton *restartButton = findChild<QPushButton*>("restartButton");
    if (restartButton) {
        restartButton->setVisible(false);
    }

    gameMode = Active;
    resetGame();
    gameTimer->start(16);
}

void MainWindow::resetGame()
{
    playerPaddle.moveTo(width() - paddleWidth, height() - paddleHeight);
    computerPaddle.moveTo(width() - paddleWidth, 0);
    ball.moveTo(width() / 2 - ballSize / 2, height() / 2 - ballSize / 2);

    ballDirection = QPoint(1, 1);

    score = 0;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    emit aboutToClose();
    QMainWindow::closeEvent(event);
}
