#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QRect>
#include <QPoint>
#include <QTimer>
#include <QCloseEvent>
#include <QMessageBox>
#include <QPushButton>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event);
    void keyPressEvent(QKeyEvent *event);
    void closeEvent(QCloseEvent *event);

signals:
    void aboutToClose();

private slots:
    void updateGame();
    void startGame();
    void restartGame();
    void resetGame();
    void showGameOverMessage();

private:
    Ui::MainWindow *ui;

    QTimer *gameTimer;

    int paddleWidth;
    int paddleHeight;
    int paddleSpeed;

    int ballSize;
    int ballSpeed;

    QRect playerPaddle;
    QRect computerPaddle;
    QRect ball;

    QPoint ballDirection;

    int score;

    enum GameMode {
        Active,
        GameOver
    };

    GameMode gameMode;

    void moveBall();
    void movePlayerPaddleLeft();
    void movePlayerPaddleRight();
    void moveComputerPaddle();
    void checkCollisions();
};

#endif // MAINWINDOW_H
